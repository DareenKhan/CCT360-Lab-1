// Selects all story sections that should appear while scrolling
var storySections = document.querySelectorAll(".reveal");


window.addEventListener("scroll", function() {

  for (var i = 0; i < storySections.length; i++) {

    //  Position of each story section
    var sectionPosition = storySections[i].getBoundingClientRect().top;

    // When the section should appear
    var screenPosition = window.innerHeight * 0.8;

    // Adds the "show" class when the section enters the screen
    if (sectionPosition < screenPosition) {
      storySections[i].classList.add("show");
    }
  }

});
